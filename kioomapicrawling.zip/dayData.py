import sys
from PyQt5.QtWidgets import *
import Kiwoomtmp
import time
from pandas import DataFrame
import csv
import cx_Oracle

MARKET_KOSPI   = 0
MARKET_KOSDAQ  = 10

class PyMon:
    def __init__(self):
        self.kiwoom = Kiwoomtmp.Kiwoom()
        self.kiwoom.comm_connect()
        self.get_code_list()

    def get_code_list(self):
        self.kospi_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSPI)
        self.kosdaq_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSDAQ)

        # f = open('kospi.csv', 'w', encoding='utf-8', newline='')
        # wr = csv.writer(f)
        # for i in self.kospi_codes:
        #     wr.writerow([i])
        # f.close()
        #
        # t = open('kosdaq.csv', 'w', encoding='utf-8', newline='')
        # wr = csv.writer(t)
        # for i in self.kosdaq_codes:
        #     wr.writerow([i])
        # t.close()
        # print(len(self.kosdaq_codes))
        # print(len(self.kospi_codes))

    def realRun(self):
        self.kiwoom.ohlcv = {'date': [], 'open': [], 'high': [], 'low': [], 'close': [], 'volum': []}
#        self.kiwoom.set_input_value("종목코드", '000880')
        codelist = self.kiwoom.dynamicCall("GetCodeListByMarket(QString)", 10)
#        self.kiwoom.comm_rq_data("opt10001_req", "opt10001", 0, "0101")
#        self.kiwoom.setRealReg("0101", '000880;000660;020150', ["10"], "0")

        while 1:
            time.sleep(3)
            self.kiwoom.comm_kw_rq_data(codelist[0:700], 0, 100, 0, "comm_kw", "0101")

    def get_ohlcv(self, codelist, start):
        self.kiwoom.ohlcv = {'date': [], 'open': [], 'high': [], 'low': [], 'close': [], 'volum': []}

        now = time.localtime()

        i=0

        for x in codelist:
            cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (
            now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
            print(x)
            self.kiwoom.set_input_value("종목코드", x)
            self.kiwoom.set_input_value("기준일자", start)
            self.kiwoom.set_input_value("수정주가구분", 1)
            self.kiwoom.setRealReg("0101", "000880;000660;020150;003490;001800;005930;251270", ["10;9001;"], "0")
            self.kiwoom.comm_rq_data("opt10001_req", "opt10081", 0, "0101")
            print(i)
            time.sleep(1.5)
            i += 1
            df = DataFrame(self.kiwoom.ohlcv, columns=['date', 'open', 'high', 'low', 'close', 'volum'],
                           index=self.kiwoom.ohlcv['date'])

        return df

    def run_kosdaq(self):
        now = time.localtime()
        cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

        dt = "%04d%02d%02d" % (now.tm_year, now.tm_mon, now.tm_mday)

        kosdaq_df = self.get_ohlcv(self.kosdaq_codes[400:], dt)

        kosdaq_df.to_csv("./kosdaqdaydata.csv", sep=';', na_rep='NaN', mode='a')

        print(kosdaq_df)
        return kosdaq_df


    def run_kospi(self):
        now = time.localtime()
        cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

        dt = "%04d%02d%02d" % (now.tm_year, now.tm_mon, now.tm_mday)

        kospi_df = self.get_ohlcv(self.kospi_codes[:999], dt)
        f = open('./kospidaydata.csv', 'a')
        csvWriter = csv.writer(f)

        csvWriter.writerow(kospi_df)
        f.close()
        print(kospi_df)
        return kospi_df

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pymon = PyMon()
#    kosdaq = pymon.run_kosdaq()
    kospi = pymon.realRun()


'''
        for x in codelist:
            cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
            print(x)
            self.kiwoom.set_input_value("종목코드", x)
            self.kiwoom.ohlcv['종목코드'].append(x)
#            self.kiwoom.set_input_value("기준일자", start)
            self.kiwoom.comm_rq_data("opt10001_req", "opt10001", 0, "0101")
            print(i)
            time.sleep(0.3)
            i +=1
            '''
 #           df = DataFrame(self.kiwoom.ohlcv, columns=['종목코드', '날짜', '최고가', '최저가', '현재가', '거래량'],
 #                          index=self.kiwoom.ohlcv['날짜'])

 #       return df