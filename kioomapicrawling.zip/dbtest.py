import cx_Oracle

conn = cx_Oracle.connect('pj2/pj2@localhost:1521/xe')
cursor = conn.cursor()
sql2 = "CREATE TABLE pj2.test4 (\
    A   Number \
    B   Number)"
#cursor.execute(sql2)
a = [(10, 20)]
statement = 'insert into test4(A, B) values (:a, :b)'
cursor.execute(statement, (10, 20))
conn.commit()
#cursor.prepare('INSERT INTO test3 (A) VALUES (:A)')
#cursor.setinputsizes(A=cx_Oracle.NUMBER)
#cursor.execute(None, {'A':st})

conn.close()
