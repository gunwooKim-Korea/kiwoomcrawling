import requests
from bs4 import BeautifulSoup
import cx_Oracle
import time

# HTTP GET Request
req = requests.get('http://news.naver.com/main/list.nhn?mode=LS2D&mid=shm&sid1=101&sid2=259')
# HTML 소스 가져오기
html = req.text
# BeautifulSoup으로 html소스를 python객체로 변환하기
# 첫 인자는 html소스코드, 두 번째 인자는 어떤 parser를 이용할지 명시.
# 이 글에서는 Python 내장 html.parser를 이용했다.
soup = BeautifulSoup(html, 'html.parser')

news_link = soup.select(
    'div.list_body.newsflash_body > ul.type06_headline > li > dl > dt'

)
#print(news_link)

#t = str(news_link[4])
#t = t.split("</dt>")
#print(t[0] +"\n")
#print(t[1] +"\n")

#print(news_link[4].dt.get('class'))
#print(news_link[4].dt.photo.a.text)

def insertRealData(news_img_src, news_link_text, news_link_src):
    print("in")
    conn = cx_Oracle.connect('pj2/pj2@localhost:1521/xe')
    cursor = conn.cursor()
    statement = 'insert into newslink values (:news_img_src, :news_link_text, :news_link_src)'
    cursor.execute(statement, (news_img_src, news_link_text, news_link_src))
    conn.commit()
    print("success")
    conn.close()

x = 0
imgsrc = ""
title = ""
link = ""
print("1")
while 1:
    time.sleep(50)
    for i in news_link:
        x += 1
        if(i.get('class')==['photo']):

            print("1")
            print("\nnews_img_src: " + i.a.img.get('src'))
            imgsrc = i.a.img.get('src')
        if(i.get('class') is None):
            print("2")
            print("\nnews_link text : " + i.a.text)
            print("\nnews_link src : " + i.a.get('href'))
            title = i.a.text
            link = i.a.get('href')

        if(imgsrc == ""):
            imgsrc = "None"
            print("3")
        if(x % 2 == 0):
            print("4")
            insertRealData(imgsrc, title, link)
        print("mid")
